fx_version 'cerulean'
game 'gta5'
this_is_a_map 'yes'
files {
	'common/*.meta'
}
data_file 'DLC_ITYP_REQUEST' 'stream/yakuza.ytyp'
